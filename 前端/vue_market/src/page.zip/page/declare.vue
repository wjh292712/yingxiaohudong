<template>
  <div class="container">
    <header class="header">
      <span>
        </span>
          <span>参与活动赢大奖</span>
    </header>
    <section class="section">

    </section>
    <footer class="footer">

    </footer>
  </div>
</template>
<script>export default ({
  data() {
    return {
      info: ""
    }

  },
  created() {

  },
  mounted() {

  },
  methods: {


  },

  components: {
  }
})
</script>

<style lang="scss">
.container {
  width: 100%;
  height: auto;
}

.header {
  width: 100%;
  height: 50px;
  background: #dec;
  flex: 1;
  justify-content: space-between;
}
</style>
