<template>
    <div class="mui-content">
        <div id="ttls">
            <p>正在参加以下砍价活动......</p>
        </div>
        <div id="bbs" class="mui-col-xs-12">
            <div id="imgg_div">
                    <img src="../assets/iconss.png">
            </div>
            <div id="right_div">
                <p>{{objects.name}}</p>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data(){
        return{
            objects:
                {
                     name:'贝多芬香水啊啊啊啊啊啊啊啊啊啊啊啊',
				shouchu:10,
				shengyu:10,
				price:900,
				pce:999 
                }
            
        
        }
    }
}
</script>

<style scoped>
#right_div{
    float: left;
    height: 100px;
   border: 1px solid #ff0000;
    position: absolute;
    left: 115px;
    top: 50%;
    margin-top:-50px;
}
#imgg_div img{
    width: 100%;
    height: 100%
}
#imgg_div{
    width: 100px;
    height: 100px;
    background: #bebebe;
    position: absolute;
    top: 50%;
    margin-top: -50px;
    margin-left: 15px;
    float: left;  
}   
#bbs{
    height: 150px;
    background: #fff3f3;
    position: relative;
}
#ttls{
    height: 50px;
    line-height: 50px;
    padding-left: 15px;
}
</style>
