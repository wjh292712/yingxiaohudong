<template>
    <div id="ddvss">
        <router-view></router-view>
    </div>
</template>

<script>
export default {

}
</script>

<style>
body,html{
    height: 100%
}
#ddvss{
    height: 100%
}
ul{
  margin:0px 0px;
 padding: 0px 0px 
}
ul li{
  list-style: none;
}
p{
    margin: 0px 0px;
    padding: 0px 0px
}
</style>
