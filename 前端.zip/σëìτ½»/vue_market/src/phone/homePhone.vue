<template>
    <div class="mui-content">
        <div id="main">
            
        </div>
    </div>
</template>

<script>
import '../plugins/sudoku/jquery-1.11.0.js';
export default {

}
</script>

<style scoped>
#main{
background-image: url("../assets/home.png");
background-repeat: no-repeat;

}
</style>
