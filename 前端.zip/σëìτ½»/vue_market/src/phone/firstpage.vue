<template>
  <div class="mui-content" style="height:100%">
   

    <section class="section" style="height:100%">
      <nav class="nav">
        <img src="../assets/images/banner.jpg" alt="">
      </nav>
      <div class="cent">
        <img src="../assets/images/tell.png" alt="">

      </div>
      <div class="setting">
        <div class="setting_img">
          <img src="../assets/images/setting.png" alt="" id="bg" >
        </div>
        <!-- <img src="../assets/images/setting.png" alt=""> -->
        <div class="ten">
          <div class="box">
          <div id="ddvs">
          <img style="opacity:1" class="img_bei mui-col-xs-3" v-for="(item,index) in url" :src="item" alt="111" name="pic" :key="index" onclick="ZhuanDong()">
          </div>
          </div>
        </div>
      </div>
      <div class="change">
        <span>
        
        </span>
      </div>
      <div class="btns">
        <span>
          <button class="left_btn" @click="dialogVisible=true">活动规则</button>
        </span>
        <span>
          <button class="right_btn" style="margin-left:15px">我的奖品</button>
        </span>
      </div>
         <el-dialog
         class="dialogs"
          title="提示"
           :visible.sync="dialogVisible"
          width="98%"
         >
        <pop></pop>

         </el-dialog>
    </section>
  </div>
</template>


<script>

import '../../static/css/index.css';
import '../../static/js/indexs.js'
import '../plugins/sudoku/jquery-1.11.0.js';
import pop from '../components/propView'
export default {
  components:{pop},
  data() {
    return {
      dialogVisible:false,
      url: [
        require('../assets/images/111.jpg'),
        require('../assets/images/111.jpg'),
        require('../assets/images/111.jpg'),
        require('../assets/images/111.jpg'),
        require('../assets/images/prize.jpg'),
        require('../assets/images/111.jpg'),
        require('../assets/images/111.jpg'),
        require('../assets/images/111.jpg'),
        require('../assets/images/111.jpg')
      ]
    }
  },
  methods:{
  },
  mounted(){
    let url = window.href;
    ulr = url.substr(url.lastindexof("?"))
    alert(url)
    
  }
}
</script>
<style>
.el-message-box{
  width: 98% !important;
}
.el-message-box{
  height: 300px;
}

body,html{
  height: 100%;
  width: 100%
}

.dialogs .el-dialog__body{
  background:#fff !important;
  padding: 30px 20px !important
}
.dialogs .el-dialog__header .el-dialog__headerbtn .el-icon-close{
display:block !important ;
}
</style>

<style  scoped>

body{
  height: 100%;
  width: 100%;
}
.section{
    height: 100% !important;
}

container {
  width: 100% !important;
  height: 100;
  background: #DEC;
}
#bg{
  position: relative;
}

.header {
  width: 100%;
  height: 50px;
  background: #fff;
  display: flex;
  justify-content: space-between;
  line-height: 50px;
  padding: 0 0.3rem;
  font-size: 16px;
}

.header a {
  color: #333;
  font-size: 16px;
  /*adding: 0 0.3rem; */
}

.section {
  width: 100%;
  height: 100% !important;
  background: #FFD800;
  flex: 1;
  overflow-y: scroll;
}

.section .nav {
  width: 100%;
  height: 150px;
}

.section .nav img {
  width: 100%;
  height: 100%;
}



.section .cent {
  width: 100%;
  height: 2rem;
  margin: 0 auto;
}
.mui-col-xs-3{
  width: 26% !important
}
#ddvs{
  width: 95%;
  height: 100%;
  position: absolute;
  left: 50%;
  margin-left: -42%;

 top: 4px
}
.section .cent img {
  width: 80%;
  height: 80%;
  /* margin: auto; */
  text-align: center;
  margin-left: 7%;
}

.section .setting {
  width: 100%;
  height: 12rem;
  position: relative;
}

.section .setting img {
 
}

.section .change {
  width: 100%;
  height: 3rem;
  text-align: center
}

.section .change span {

  height: 3rem;
  line-height: 3rem;
 
}

.section .setting_img {
  width: 100%;
  height: 12rem;
  margin-left: 10%;
  position: relative;
}

.section .setting_img img {
  width: 80%;
  height: 100%;
}

.section .setting .ten {
  width: 100%;
margin-left: 19%;
  height: 10.5rem;
  background-size: 100%;
  position: absolute;
  top: 0px;
  
}

.section .btns {
  width: 100%;
  height: 3rem;
text-align: center;
  justify-content: space-between;
 
}

.section .btns span {
  height: 3rem;
  margin-top: 1rem;
  width: 6rem;
}

.section .btns span .left_btn {
  height: 2rem;
  background: #FC5566;
  width: 6rem;
  border-radius: 1rem;
  outline: none;
  outline: none;
  border: none;
  color: #fff;
}

.section .btns span .right_btn {
  height: 2rem;
  background: #FC5566;
  width: 6rem;
  border-radius: 1rem;
  outline: none;
  border: none;
  color: #F7C727;
}
</style>


